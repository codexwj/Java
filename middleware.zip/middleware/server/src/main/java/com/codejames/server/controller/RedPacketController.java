package com.codejames.server.controller;

import com.codejames.middleware.api.enums.BaseResponse;
import com.codejames.middleware.api.enums.StatusCode;
import com.codejames.server.dto.RedPacketDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author codexwj
 * @CSDN https://blog.csdn.net/qq_31900497
 * @Github https://github.com/codexwj
 * @微信公众号 codexwj
 * @date 2021/1/3
 **/
@RestController
public class RedPacketController {
    //定义日志
    private static final Logger log = LoggerFactory.getLogger(RedPacketController.class);
    //定义请求路径前缀
    private static final String prefix = "red/packet";
    //注入红包处理业务
    @Autowired
    private IRedPacketService redPacketService;

//    发红包请求-请求方法为Post，请求参数采用JSON格式进行交互
    @RequestMapping(value = prefix+"/hand/out",method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public BaseResponse handout(@Validated  @RequestBody RedPacketDto dto, BindingResult result){
     if (result.hasErrors()){
         return new BaseResponse(StatusCode.InvalidParams);
     }
    }

}
