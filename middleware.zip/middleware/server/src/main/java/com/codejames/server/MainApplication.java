package com.codejames.server;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

/**
 * @author codexwj
 * @CSDN https://blog.csdn.net/qq_31900497
 * @Github https://github.com/codexwj
 * @微信公众号 codexwj
 * @date 2021/1/3
 **/
@SpringBootApplication
@MapperScan(basePackages = "com.codejames.middleware.model")
public class MainApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder){
        return super.configure(builder);
    }

    public static void main(String[] args) {
        SpringApplication.run(MainApplication.class,args);
    }
}
