package com.codejames.server.dto;

import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.net.Inet4Address;

/**
 * @author codexwj
 * @CSDN https://blog.csdn.net/qq_31900497
 * @Github https://github.com/codexwj
 * @微信公众号 codexwj
 * @date 2021/1/3
 **/
@Data
@ToString
public class RedPacketDto {
    private Integer userId;
    @NotNull
    private Integer total;
    @NotNull
    private Integer amount;
}
