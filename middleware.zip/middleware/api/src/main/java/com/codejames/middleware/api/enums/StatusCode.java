package com.codejames.middleware.api.enums;

import com.sun.net.httpserver.Authenticator;

/**
 * @author codexwj
 * @CSDN https://blog.csdn.net/qq_31900497
 * @Github https://github.com/codexwj
 * @微信公众号 codexwj
 * @date 2021/1/3
 **/
public class StatusCode {
//    Success(0,"成功");

    private Integer code;
    private String msg;

    StatusCode(Integer code, String msg){
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
